#include <p18f4620.h>
#include "Main.h"
#include "Fan_Support.h"
#include "stdio.h"

extern char FAN;
extern char duty_cycle;


int get_RPM()
{

}

void Toggle_Fan()
{
 
}

void Turn_Off_Fan()
{

}

void Turn_On_Fan()
{
 
}

void Increase_Speed()
{



}

void Decrease_Speed()
{
 
}

void do_update_pwm(char duty_cycle) 
{ 

}

void Set_DC_RGB(int duty_cycle)
{
    
}

void Set_RPM_RGB(int rpm)
{
    
}



