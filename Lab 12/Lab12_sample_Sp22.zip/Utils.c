#include <p18f4620.h>
#include "Main.h"
#include "Utils.h"
#include "stdio.h"

void Do_Beep()
{

}

void Wait_One_Sec()
{

}

void Activate_Buzzer()
{

}

void Deactivate_Buzzer()
{

}

