
void Do_Setup_Heater_Temp(void);
void Initialize_Setup_Heater_Screen(void) ;
void Update_Setup_Heater_Screen(void);
void Decrease_Heater_Temp();
void Increase_Heater_Temp();
void Exit_Setup_Heater_Temp();
void Do_Save_New_Heater_Temp();


//  Setup DC Screen   
#define setup_heater_x          15
#define setup_heater_y          60    
#define setup_data_heater_x     40
#define setup_data_heater_y     74