void interrupt  high_priority chkisr(void) ;
void T0_ISR();
void INT0_isr(void);
void INT1_isr(void);
void INT2_isr(void);
void TIMER1_isr(void);
void Init_Interrupt(void);
void force_nec_state0();

