void Do_Setup_Time(void);
void Increase_Time(void);
void Decrease_Time(void);
void Go_Next_Field(void);
void Go_Prev_Field(void);
void Do_Save_New_Time(void);
void Initialize_Setup_Time_Screen(void);
void Update_Setup_Time_Screen(void);
void Update_Setup_Screen_Cursor_Forward(char);
void Update_Setup_Screen_Cursor_Backward(char field);
void Do_Save_New_Time();
void Exit_Time_Setup();

